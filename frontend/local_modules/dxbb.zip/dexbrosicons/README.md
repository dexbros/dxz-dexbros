# Crypto icons by dexbros/gm

## Installation

`npm install --save https://github.com/jayboro100/dexbros-icons`


## Usage

```html
import 'dexbros-icons/styles.css';
<span class="icon icon-btc"></span>
```


## License

Icons are licensed under the [MIT](/LICENSE.md) License.


Enjoy!.
