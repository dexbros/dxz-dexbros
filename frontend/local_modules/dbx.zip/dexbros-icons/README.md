# Crypto icons by dexbros/gm

## Installation

`npm i dexbros-icons`


## Usage

```html
<span class="icon icon-btc"></span>
```


## License

Icons are licensed under the [MIT](/LICENSE.md) License.


Enjoy!.
